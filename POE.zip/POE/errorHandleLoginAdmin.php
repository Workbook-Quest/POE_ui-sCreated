<?php
//Session initialized
session_start();

//include connection source code.
 include("DBConn.php");

 //Check to see if the user has already logged in. If the user is logged in then redirect them to Workbook Quest home logged in.
 if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true)
 {
    header("location: workbookQuest.php");
    exit;
}

//error count equals to zero.
 $countError = 0;
 //initialize with emty value the newly declared variables.
 $adminUsername_error = $adminPwd_error = "";
 $adminUser = $adminPwd = "";

 //If register.php submit button has been clicked then do the following.
 if(isset($_POST["submitAdminLog"]))
 {
     //If input value of type=name is empty then the following error message will display.
    if(empty($_POST['adminname']))
    {
        $adminUsername_error = "Please input the username.";
        $countError++;//error count starts to count.
    }
    else//if it is not empty then $name = type=name. 
    {
        $adminUser = $_POST['adminname'];
    }

    if(empty($_POST['adminPwd']))
    {
        $adminPwd_error = "Please input the password.";
        $countError++;
    }
    else
    {
        $adminPwd = $_POST['adminPwd'];
    }

    if($countError == 0)
    {

        $usernameCheck = mysqli_real_escape_string($connectMyDB, $_POST['adminname']);
        $passwordCheck = password_hash(mysqli_real_escape_string($connectMyDB, $_POST['adminPwd']), PASSWORD_DEFAULT);

        //Select id, username and password from tbladmin where username = $usernameAdmin
        $sql = "SELECT AdminUsername, AdminPassword password FROM tbadmin WHERE AdminUsername = '$usernameCheck' && AdminPassword = '$passwordCheck' ";
    

      //query execution
      $dbResult = mysqli_query($connectMyDB, $sql);

      $fetchRow = mysqli_fetch_array($dbResult, MYSQLI_ASSOC);

      $activate = $fetchRow['active'];

      $countResult = mysqli_num_rows($dbResult);

      if ($dbResult === FALSE) 
      {
        echo "Error: ". mysqli_connect_error();
      } 
      else 
      { 
        //insert values have succesfully been inserted.
        session_start();
        $_SESSION['message'] = "User has been logged in succesfully.";
        $_SESSION['msg_type'] = "success";
        header('location: workbookQuest.php');
      }

        //closing the connection
        mysqli_close($connectMyDB);
        $connectMyDB = FALSE;
    }
    unset($_POST["submit"]);
 }


?>