<?php

    include("DBConn.php");

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Workbook Quest</title>
        <link rel="styleSheet" type="text/css" href="styles.css">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        
    <div class = "bg-image">
    <div class = "nav" id="myNav">
            <ul>                
                <li><a href="workbookQuest.php" >How it works</a></li>
                <li><a href="bookListLoggedIn.php">Book List</a></li>
                <li><a href="contactUsLoggedIn.php">Contact Us</a></li>
                <li><a href="wishlist.php" class = "active">Wishlist</a></li>
                <li><a href="account.php">Account</a></li>
                <li><a href="logOut.php" style = "color: white;">Log Out</a></li>
                <li><a href="cart.php" style="background:red;"><img alt src="images/cart.png" style="width: 40px; height: 40px;"></a></li>
            </ul>
        </div>
        
       <div class="top" style="height: 100px; background-color: transparent"></div>
       <div class="main">
       <h1 style="font-size: 40px; color: white; text-align:left">Wishlist</h1>
        
        <table style="border:none; margin-left:60px; color:black;">
            <tr>
                <th><button class="btn">ADD TO CART</button></th>
                <th><button class="btn"><img alt src="images/cancel.png" style="height:40px; width:40px;"></button></th>
            </tr>
        </table>
       
        </div>
       </div>
    </body>
</html>


