<?php

    include("DBConn.php");

?>

<!DOCTYPE html>
<html>
    <head>
        <title>Workbook Quest</title>
        <link rel="styleSheet" type="text/css" href="styles.css">
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        
    <div class = "bg-image">
    <div class = "nav" id="myNav">
            <ul>                
                <li><a href="workbookQuest.php" >How it works</a></li>
                <li><a href="bookListLoggedIn.php">Book List</a></li>
                <li><a href="contactUsLoggedIn.php">Contact Us</a></li>
                <li><a href="wishlist.php">Wishlist</a></li>
                <li><a href="account.php" class = "active">Account</a></li>
                <li><a href="logOut.php" style = "color: white;">Log Out</a></li>
                <li><a href="cart.php" style="background:red;"><img alt src="images/cart.png" style="width: 40px; height: 40px;"></a></li>
            </ul>
        </div>
        
       <div class="top" style="height: 100px; background-color: transparent"></div>
       <div class="main">
       <h1 style="font-size: 40px; color: white; text-align:left">Account</h1>
        
       <h3 style="color:black; text-align:left; "><img alt src="images/account.jpg" style="width: 40px; height: 40px; background:red;">  Personal Details<br></h3>

        <table style="border:none; margin-left:60px; color:black;">
            <tr>
                <th>Name:</th>
            </tr>
            <tr>
                <th>Surname:</th>
            </tr>
            <tr>
                <th>Student Number:</th>
            </tr>
            <tr>
                <th>Email Address:</th>
            </tr>
            <tr>
                <th>Username:</th>
            </tr>
            <tr>
                <th>Password:</th>
                <th><button class="btn">CHANGE PASSWORD</button></th>
            </tr>
            <tr>
                <th>Seller:</th>
                <th><input type="checkbox" name="name1" /></th>
            </tr>
        </table>
       
       <!--img alt src="images/bookOrder.png" style="width: 40px; height: 40px; background:red;"-->
       <h3 style="color:black; text-align:left; "><img alt src="images/bookOrder.png" style="width: 40px; height: 40px; background:red;">  Orders and tracking<br></h3>
        </div>
       </div>
    </body>
</html>


